rootProject.name = "enigmagent-vault"

plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "0.8.0"
}
